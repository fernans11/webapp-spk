"""
methods/ahp.py - AHP Method (for full decision making)
Analytic Hierarchy Process
"""

import numpy as np
from typing import Dict, List, Tuple
import logging

logger = logging.getLogger(__name__)


class AHP:
    """AHP Method Implementation"""
    
    @staticmethod
    def calculate_priorities(pairwise_matrix: np.ndarray) -> Tuple[np.ndarray, float]:
        """
        Calculate priorities from pairwise comparison matrix
        
        Returns:
            Priorities vector and lambda_max
        """
        n = pairwise_matrix.shape[0]
        pairwise = pairwise_matrix.astype(float)
        
        # Normalize columns
        col_sums = np.sum(pairwise, axis=0)
        normalized = pairwise / col_sums
        
        # Calculate priorities (row averages)
        priorities = np.mean(normalized, axis=1)
        
        # Calculate lambda_max
        weighted_sum = np.dot(pairwise, priorities)
        lambda_max = np.mean(weighted_sum / priorities)
        
        return priorities, lambda_max
    
    
    @staticmethod
    def calculate(criteria_names: List[str],
                 alternatives: List[str],
                 criteria_pairwise: np.ndarray,
                 alternatives_pairwise_list: List[np.ndarray]) -> Dict:
        """
        AHP Method:
        1. Calculate criteria weights from pairwise matrix
        2. Calculate alternative scores for each criterion
        3. Calculate overall scores
        4. Rank alternatives
        
        Args:
            criteria_names: List of criterion names
            alternatives: List of alternative names
            criteria_pairwise: NxN pairwise comparison for criteria
            alternatives_pairwise_list: List of MxM pairwise matrices for each criterion
            
        Returns:
            Results dictionary
        """
        n_criteria = len(criteria_names)
        n_alts = len(alternatives)
        
        # Step 1: Calculate criteria weights
        criteria_weights, lambda_max_c = AHP.calculate_priorities(criteria_pairwise)
        
        # Step 2: Calculate alternative priorities for each criterion
        alternative_priorities = np.zeros((n_alts, n_criteria))
        lambda_max_values = []
        
        for j in range(n_criteria):
            alt_priorities, lambda_max = AHP.calculate_priorities(alternatives_pairwise_list[j])
            alternative_priorities[:, j] = alt_priorities
            lambda_max_values.append(lambda_max)
        
        # Step 3: Calculate overall scores (weighted sum)
        overall_scores = np.dot(alternative_priorities, criteria_weights)
        
        # Step 4: Rank
        rankings = np.argsort(overall_scores)[::-1]
        
        # Calculate CR for criteria
        ri_values = {1: 0, 2: 0, 3: 0.58, 4: 0.90, 5: 1.12, 
                    6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45}
        ci_c = (lambda_max_c - n_criteria) / (n_criteria - 1) if n_criteria > 1 else 0
        ri_c = ri_values.get(n_criteria, 1.45)
        cr_c = ci_c / ri_c if ri_c > 0 else 0
        
        ci_a = (lambda_max_values[0] - n_alts) / (n_alts - 1) if n_alts > 1 else 0
        ri_a = ri_values.get(n_alts, 1.45)
        cr_a = ci_a / ri_a if ri_a > 0 else 0
        
        results = {
            'method': 'AHP (Analytic Hierarchy Process)',
            'criteria_weights': [float(w) for w in criteria_weights],
            'lambda_max_criteria': float(lambda_max_c),
            'consistency_index_criteria': float(ci_c),
            'consistency_ratio_criteria': float(cr_c),
            'consistency_ok_criteria': cr_c < 0.1,
            'alternative_priorities': alternative_priorities.tolist(),
            'overall_scores': [float(s) for s in overall_scores],
            'scores': [float(s) for s in overall_scores],
            'rankings': [int(r+1) for r in rankings],
            'alternative_rankings': {alternatives[r]: int(i+1) for i, r in enumerate(rankings)},
            'best_alternative': alternatives[rankings[0]],
            'best_score': float(overall_scores[rankings[0]]),
            'worst_alternative': alternatives[rankings[-1]],
            'worst_score': float(overall_scores[rankings[-1]]),
            'calculation_steps': {
                'criteria_pairwise': criteria_pairwise.tolist(),
                'criteria_weights_formula': 'Geometric mean of normalized columns',
                'overall_score_formula': 'Σ(criterion_weight × alternative_priority)',
                'detailed_calculations': []
            }
        }
        
        # Detailed calculations
        for i in range(n_alts):
            calc = {
                'alternative': alternatives[i],
                'score': float(overall_scores[i]),
                'ranking': int(np.where(rankings == i)[0][0] + 1),
                'weighted_priorities': []
            }
            
            for j in range(n_criteria):
                weighted_priority = {
                    'criterion': criteria_names[j],
                    'weight': float(criteria_weights[j]),
                    'priority': float(alternative_priorities[i, j]),
                    'weighted': float(criteria_weights[j] * alternative_priorities[i, j])
                }
                calc['weighted_priorities'].append(weighted_priority)
            
            results['calculation_steps']['detailed_calculations'].append(calc)
        
        return results


def calculate_ahp(criteria_names: List[str],
                 alternatives: List[str],
                 criteria_pairwise: np.ndarray,
                 alternatives_pairwise_list: List[np.ndarray]) -> Dict:
    """Calculate AHP method"""
    return AHP.calculate(criteria_names, alternatives, criteria_pairwise, alternatives_pairwise_list)

